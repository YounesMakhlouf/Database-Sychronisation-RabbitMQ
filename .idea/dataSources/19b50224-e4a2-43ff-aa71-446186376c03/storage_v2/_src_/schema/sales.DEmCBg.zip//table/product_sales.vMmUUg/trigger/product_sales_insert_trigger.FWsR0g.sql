create definer = sqluser@localhost trigger product_sales_insert_trigger
    after insert
    on product_sales
    for each row
BEGIN
    CALL capture_changes(CONCAT(
            'INSERT INTO product_sales (date, region, product, quantity, cost, amount, tax, total) VALUES (''',
            NEW.date, ''', ''', NEW.region, ''', ''', NEW.product, ''', ', NEW.quantity, ', ', NEW.cost, ', ',
            NEW.amount, ', ', NEW.tax, ', ', NEW.total, ');'));
END;

