create definer = sqluser@localhost trigger product_sales_delete_trigger
    after delete
    on product_sales
    for each row
BEGIN
    DECLARE sql_stmt VARCHAR(2000);
    SET sql_stmt = CONCAT('DELETE FROM product_sales WHERE date = \'', OLD.date, '\' AND region = \'', OLD.region,
                          '\' AND product = \'', OLD.product, '\';');
    CALL capture_product_sales_changes(sql_stmt);
END;

