create definer = sqluser@localhost trigger product_sales_update_trigger
    after update
    on product_sales
    for each row
BEGIN
    DECLARE sql_stmt VARCHAR(2000);
    SET sql_stmt =
            CONCAT('UPDATE product_sales SET date = \'', NEW.date, '\', region = \'', NEW.region, '\', product = \'',
                   NEW.product, '\', quantity = ', NEW.quantity, ', cost = ', NEW.cost, ', amount = ', NEW.amount,
                   ', tax = ', NEW.tax, ', total = ', NEW.total, ' WHERE date = \'', OLD.date, '\' AND region = \'',
                   OLD.region, '\' AND product = \'', OLD.product, '\';');
    CALL capture_product_sales_changes(sql_stmt);
END;

