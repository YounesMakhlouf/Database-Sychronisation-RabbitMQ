create
    definer = sqluser@localhost procedure capture_changes(IN s_query varchar(2000))
BEGIN
    INSERT INTO product_sales_changes_log (query)
    VALUES (s_query);
END;

